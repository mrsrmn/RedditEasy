from .subreddit import Subreddit
from .user import User

__version__ = "2.5.0"
__author__ = "MakufonSkifto"
__license__ = "GNU General Public License v3"
