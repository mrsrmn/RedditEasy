class RequestError(Exception):
    pass
