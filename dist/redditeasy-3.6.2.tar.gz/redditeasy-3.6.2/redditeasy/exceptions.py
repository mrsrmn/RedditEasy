class RequestError(Exception):
    pass


class EmptyResult(Exception):
    pass
